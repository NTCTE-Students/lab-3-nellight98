<?php

$array = ['a', 'b', 'c', 'd', 'e'];
print ("Количество элементов: " . count($array) );