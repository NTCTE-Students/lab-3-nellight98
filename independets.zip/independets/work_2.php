<?php
$numbers = [5, 2, 9, 1, 5, 6];
print ("Максимум: " . max($numbers) . "<br>");
print ("Минимум:" . min($numbers) ."<br>");