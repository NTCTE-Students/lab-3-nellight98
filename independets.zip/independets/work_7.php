<?php

$string = "Я крутой пепсик";
$words = explode(" ", $string);
print ("Слова: " . implode(", ", $words) );